from flask import Flask, request, render_template

from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sdfghjklç~zsertgbnmkuygfcxshjnm'

if __name__ == "__main__":
    app.run()

@app.route('/')
def index():
    return render_template('template.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route("/oi", defaults={'name': 'Desconhecido'})
@app.route("/oi/<name>")
def oi(name):
    return "Boa tarde, %s" % name

@app.route('/data/<int:dia>')
def dia(dia):
    return "Hoje é dia %i" % dia

@app.route('/tipo', methods=['POST', 'GET'])
def tipo():
    if request.method == 'POST':
        return 'Solicitação via método POST'
    else:
        return 'Solicitação via método GET'

@app.route('/ola')
@app.route('/ola/<name>')
def ola(name=None):
    return render_template('hello.html',name=name)


@app.route('/formulario', methods=['POST', 'GET'])
def formulario():
    meuformulario = Form()
    if request.method == 'POST':
        if meuformulario.validate_on_submit():
            print(meuformulario.nome)
            return 'Solicitação via método POST do formulario'
        else:
            print(meuformulario.errors)
            return 'Erros ocorreram...'
    else:
        return render_template('formulario.html', meuform=meuformulario)


class Form(FlaskForm):
    nome = StringField('nome', validators=[DataRequired()])